#Welcome To Land Valley
<br/>
Welcome to Land Valley. This is the ultimate destination to find your new home.

![Home Img](img/home.jpg)

#About
<br/>
Looking for a new apparment!! or a new space for office!?<br/>
Or do you want to sell or give your property in rent?<br/>

No more hastle to find this services.<br/>
We are here to help you.<br/>
Here you can Buy, Rent or Sell property by without any hastle.<br/>
<br/>
In our website you can upload an advertisement to sell or to give rent for your property. Or you can search for a property that you like to buy or rent in no time.

#Features
<br/>

Here are the features Land Valley Has.

##User
<br/>
There is two type of user registers to our website. One is Normal User and another one is Builder.

![Home Img](img/user.jpg)

###Normal User
<br/>
Normal User are the peoples who just want to buy, sell or rent their property. And thats all for them. They can easily use our website by registering or logging in from the normal user section.

###Builder
<br/>
There are lots of Real State companys who build houses or others commercial buildings. They can also join our community and find customers for them in a single platform. As these companys are doing business, we offer them special treatment in our community so that they can get some benifites from our software. That's the reason there is a totally different section for developers in our system.

##Buy, Sell or Rent
<br/>
People can buy, sell or rent properties directly from our websites easilly. They can find enlisted properties in different sections in terms of selling or renting advertisement. Both of them have the different sections. So that user can find their desire property easily.

##Searching
<br/>
User can sort enlisted properties by serching with loations and city.

![Home Img](img/search and add.jpg)

##Property Cart
<br/>
Every enlisted property is storred in a individual carts. Anyone can see the details of that property jusy by clicking on them. While listing property, user uploads several photos of that property and write details of that property. And anyone can see those details just clicking on cart.

![Home Img](img/cart.jpg)

##Listing Advertisement
<br/>
There is two different sections where you can add your property for rent or for sell.

![Home Img](img/enlistingProperty.jpg)

##Payment Method
<br/>
We will have our own Payment Getway very soon. Currently the feature is under development. This will be available after the next version update.

##Packers and Movers
<br/>
We have a very special feature in our system. Hiring people is always a big hastle for shifting our house or office or whatever.<br/>
We are offering a whole new feature where you can find the right person to help you to shift your home, office etc.<br/>
Not only hiring, you Need a JOB!!!<br/>
This is for you. You can easily enlist yourself here if you want to help others for some extra income.

![Home Img](img/packersNmovers.jpg)

##Upcoming Projects
<br/>
In this section, Developers can add their future projects details so that consumers can see and make a plan about buying their new home or office.

![Home Img](img/Upcoming.jpg)

#Version

This in the version `0.1.9` of Land Valley you're currently using.
<br/>
Very soon we will release our stable version `1.0.1`.


<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>

