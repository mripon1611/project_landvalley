#About Us

This software is developed by the students of UIU for project showcase of the course...

#####SOFTWARE ENGINEERING LABORATORY
#####Section: A
#####Course Teacher: Md. Saidul Hoque Anik (Lecturer of UIU)

<br/>

##Developers

Niamul Chowdhury<br/>
A.S.M. Shad<br/>
Md. Alwoadud Ripon<br/>
Md Abu Hashem Shunto<br/>
Md. Nahid Hasan Foud<br/>
Md. Shahbaz Anwar<br/>
